This directory contains images linketd or used in documentation/info files
